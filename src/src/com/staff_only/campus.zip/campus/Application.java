package com.staff_only.campus; // 팀 번호에 맞게 변경

import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int menu;
        do {
            System.out.println("===== 대학생활 계산기 =====");
            // (1) 각자 자기 메뉴 한 줄 추가
            System.out.println("0. 종료");
            System.out.print("메뉴 선택 : ");
            menu = sc.nextInt();

            switch (menu) {
                // (2) 각자 자기 case 블록 추가
                case 2:
                    Scanner scn = new Scanner(System.in);

                    //입력 받은 값을 저장하기 위한 배열을 생성
                    int[] score = new int[3];

                    // 총 5번을 입력 받아서 저장해야 함.
                    // 반복
                    for (int i = 0; i< score.length; i++) {
                        System.out.print("과목" + (i + 1) + "의 점수를 입력해주세요 : ");
                        score[i] = sc.nextInt();
                    }

//                    System.out.print("과목 1 점수 : ");
//                    int score1 = sc.nextInt();
//                    System.out.print("과목 2 점수 : ");
//                    int score2 = sc.nextInt();
//                    System.out.print("과목 3 점수 : ");
//                    int score3 = sc.nextInt();

                        //1. 객체 생성
                        GradeService gs = new GradeService();

                        //2. gpac.makeReport(score[i]);으로 변수넘김
                        String result = gs.makeReport(score[0], score[1], score[2]);

                        System.out.println(result);
                        break;
                    }
                case 0:
                    System.out.println("계산기를 종료합니다.");
                    break;
                default:
                    System.out.println("없는 메뉴입니다. 다시 선택하세요.");
            }
            System.out.println();
        } while (menu != 0);
    }
}